
package domain;

public class CreditCard {

	private String	number;


	public String getNumber() {
		return this.number;
	}
}
